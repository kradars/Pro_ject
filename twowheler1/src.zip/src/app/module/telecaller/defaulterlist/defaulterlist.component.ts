import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaulterlist',
  templateUrl: './defaulterlist.component.html',
  styleUrls: ['./defaulterlist.component.css']
})
export class DefaulterlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
