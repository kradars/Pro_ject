export class Defaulter {
    sanctionId:number;
	amountPaidDate:string;
	tenure:number;
	transferAmount:number;
	totalAmount:number;
}
