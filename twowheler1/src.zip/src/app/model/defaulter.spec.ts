import { Defaulter } from './defaulter';

describe('Defaulter', () => {
  it('should create an instance', () => {
    expect(new Defaulter()).toBeTruthy();
  });
});
