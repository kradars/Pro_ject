import { LoanDisbursement } from './loan-disbursement';

describe('LoanDisbursement', () => {
  it('should create an instance', () => {
    expect(new LoanDisbursement()).toBeTruthy();
  });
});
