import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewequiry',
  templateUrl: './viewequiry.component.html',
  styleUrls: ['./viewequiry.component.css']
})
export class ViewequiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
