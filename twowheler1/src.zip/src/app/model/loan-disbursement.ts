export class LoanDisbursement {
    sanctionId:number;
	lonecaseno:number;		//dOUBLE->iNTEGER
	offerletterAcceptedDate:string;
	amountPayType:string;
	totalAmount:number;
	bankName:string;
	accoutNumber:number;
	ifsccode:string;	//INTEGER->STRING
	accountType:string;
	transferAmount:number;
	paymentStatus:string;
	amountPaidDate:string;
	tenure:number;
}
