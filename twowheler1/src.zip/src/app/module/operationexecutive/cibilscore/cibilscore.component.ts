import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cibilscore',
  templateUrl: './cibilscore.component.html',
  styleUrls: ['./cibilscore.component.css']
})
export class CibilscoreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
