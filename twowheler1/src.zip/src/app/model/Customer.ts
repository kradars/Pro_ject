
export class Customer {
  studentId: number;
  firstName: String;
  lastName: String;
  mobNo: String;
  studentEmail: String;
  studentEvent: String;
  }


